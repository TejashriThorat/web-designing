function validate() {
    let first_name = document.getElementById("name");
    let user_email = document.getElementById("email")
    let user_msg = document.getElementById("msg")
    let email_pat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (first_name.value == "") {
        alert("Please Enter Your Name!");
        first_name.focus();
        return false;
    }
    else if (user_email.value == "" || !user_email.value == email_pat) {
        alert("Please Enter Correct Email Id!");
        user_email.focus();
        return false;
    }
    else if (user_msg.value == "") {
        alert("Please Enter Your Query or Message!");
        user_msg.focus();
        return false;
    }
    else {
        return sendmessage()
    }
}

function sendmessage() {
    document.getElementById("myForm").reset();
    document.getElementById("successmsg").innerHTML = ("Message Sent Successfully!!");
}