function orderplaced() {
    document.getElementById('orderplaced').innerHTML = 'Thank you for order! Your Order has been placed Successfully!!'
}